function [xk,k,costF,normGk] = LMAlgorithm(lambda0,x0,epsl,maxIt)
    % Inputs: 1. dimTargetSpace: target space dimension (k)
    %         2. lambda0: initialization lambda of the LM algorithm
    %         3. hessF: hesssian of the objective function (as a function 
    %         handle)
    %         4. x0: initialization estimate
    %         5. epsl: stopping criterion
    %         6. maxIt: maximum number of iterations
    % Outputs: 1. x: output of the gradient descent method (returns NaN if
    %          stopping criterion not met after the maximum number of 
    %          iterations chosen
    %          2. k: number of iterations required for convergence if a
    %          solution was found
    %          3. costF: cost of the objective function
    %          4. normGk: norm of the gradient of the objective function
    %% LM algorithm 
    % Init variables
    costF = zeros(maxIt,1);
    normGk = zeros(maxIt,1);
    % Init algorithm
    k = 0;
    xk = x0;% vpa(x0);
    xprev = NaN;
    lambdak = lambda0;

    fprintf("Running LM.\n");
    % ---------  LM algorithm  ---------
    % ---------  compute initial objective function and gradients  ---------
    while k < maxIt
        
        % ---------  compute objective function and gradients  ---------
        if k 
            Aprev = A;
            bprev = b;          
        end
        [costF(k+1),normGk(k+1),A,b] = objectiveF(xk);
        
        % ---------  check stopping criterion  ---------
        if normGk(k+1) < epsl % Stopping criterion�
                break; 
        end

        %  ---------  check validity step  ---------
        if k && costF(k+1)<costF(k)
            lambdak = 0.7*lambdak;
        elseif k
            xk = xprev;
            A = Aprev;
            b = bprev;
            normGk(k+1) = normGk(k);
            costF(k+1) = costF(k);
            lambdak = 2*lambdak;
        end
    
        % ---------  solve least squares  ---------
        xprev = xk;
        A(end-size(x0,1)+1:end,:) = sqrt(lambdak)*eye(size(x0,1));
        b(end-size(x0,1)+1:end,1) = sqrt(lambdak)*xk;
        xk = ((A'*A)\A')*b;
   
        %  ---------  Increment iteration count  ---------
        if k fprintf("Iteration: %d | cost = %g.\n",k,costF(k+1)); end
        k = k+1;             
    end   
    if k == maxIt
        % No solution found within the maximum number of iterations
        xk = NaN;
    else
        costF = costF(2:k+1);
        normGk = normGk(2:k+1);
    end
    clear objectiveF; % clear persistent variables of objective function
end
